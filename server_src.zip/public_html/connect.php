<?php

$username = "e1100617";
$password = "v5ZeGaHttjxs";
$hostname = "mysql.cc.puv.fi";
$conn = mysql_connect($hostname,$username,$password);    
	
?>